import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD5t22IaSfQNdVCzaJdXcYG6doizWZc3Io",
  authDomain: "gen-lang-client-0253129413.firebaseapp.com",
  projectId: "gen-lang-client-0253129413",
  storageBucket: "gen-lang-client-0253129413.firebasestorage.app",
  messagingSenderId: "108286790025",
  appId: "1:108286790025:web:f1c7b205701e5a8d867958"
};

const app = initializeApp(firebaseConfig);

// Initialize Firestore with the database ID specified in config
export const db = getFirestore(app, "ai-studio-muslimabaya-9ea58811-2b6d-4d0b-af55-32d1b45ec33f");
